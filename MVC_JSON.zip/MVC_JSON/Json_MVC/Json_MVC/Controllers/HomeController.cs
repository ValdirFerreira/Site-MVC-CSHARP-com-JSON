﻿using Json_MVC.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Mvc;


namespace Json_MVC.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Retorno com JSON bem prático";
            return View();
        }

        [HttpPost]
        public JsonResult GetEstados()
        {
            List<Estados> objCnt = new List<Estados>(Estados.GetListaEstados());
            return Json(objCnt);

        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Download(string id)
        {
            if (id.Equals("1000"))
            {

                ViewBag.Title = " Não Exite dados da nota";

                FileStream file = new FileStream(@"C:\Arquivo\Comprovante.pdf", FileMode.Open);
                //cria o leitor do arquivo   
                return File(file, "application/pdf", "Comprovante.pdf");
            }
            else
            {
                ViewBag.Title = "Exite dados da nota";
                return View("Index");
            }
        }


        public FileContentResult BaixarArquivo(string id)
        {

            string csv = "John, Steven, Smith";
            return File(new System.Text.UTF8Encoding().GetBytes(csv), "text/csv", "myreport123.csv");

        }


         [HttpPost]
        public HttpResponseMessage BaixarInicializacao(string id)
        {
            FileStream file = new FileStream(@"C:\Arquivo\Comprovante.pdf", FileMode.Open);

            BinaryReader fileStream = new BinaryReader(file);

            byte[] Arquivo = fileStream.ReadBytes((int)file.Length);

            MemoryStream stream = new MemoryStream(Arquivo);

            HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
            result.Content = new StreamContent(stream);

            result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
            result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
            {
                FileName = string.Format("{0}" + "Comprovante" + ".pdf", stream.Length)
            };

            return result;

        }







    }
}

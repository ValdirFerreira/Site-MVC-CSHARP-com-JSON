﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Json_MVC.Models
{
    public class Estados
    {

        public int idEstado { get; set; }
        public string NomeEstado { get; set; }

        public static List<Estados> GetListaEstados()
        {

            return new List<Estados>
            {

                new Estados { idEstado=1, NomeEstado = "São Paulo "},
                new Estados{ idEstado= 2, NomeEstado= "Minas Gerais"},
                new Estados{ idEstado= 3, NomeEstado="Rio de janeiro"},
                new Estados{ idEstado= 4, NomeEstado="Bahia"},
                new Estados{ idEstado= 5, NomeEstado="Parana"},
                new Estados{ idEstado= 6, NomeEstado="Alagoas"},
                new Estados{ idEstado=7, NomeEstado="Para"}

            };
        }

    }
}